#include "surf.h"
#include "vertexrecorder.h"
using namespace std;

namespace
{
    
    // We're only implenting swept surfaces where the profile curve is
    // flat on the xy-plane.  This is a check function.
    static bool checkFlat(const Curve &profile)
    {
        for (unsigned i=0; i<profile.size(); i++)
            if (profile[i].V[2] != 0.0 ||
                profile[i].T[2] != 0.0 ||
                profile[i].N[2] != 0.0)
                return false;
    
        return true;
    }
}

// DEBUG HELPER
Surface quad() { 
	Surface ret;
	ret.VV.push_back(Vector3f(-1, -1, 0));
	ret.VV.push_back(Vector3f(+1, -1, 0));
	ret.VV.push_back(Vector3f(+1, +1, 0));
	ret.VV.push_back(Vector3f(-1, +1, 0));

	ret.VN.push_back(Vector3f(0, 0, 1));
	ret.VN.push_back(Vector3f(0, 0, 1));
	ret.VN.push_back(Vector3f(0, 0, 1));
	ret.VN.push_back(Vector3f(0, 0, 1));

	ret.VF.push_back(Tup3u(0, 1, 2));
	ret.VF.push_back(Tup3u(0, 2, 3));
	return ret;
}



void buildFaces(Surface& surface, unsigned steps, unsigned profileSize) {
    // 遍历每一步
    for (unsigned s = 0; s < steps; ++s) {
        // 遍历profile中的每个点，除了最后一个，因为它将在下一个循环中作为起始点
        for (unsigned i = 0; i < profileSize - 1; ++i) {
            // 计算四边形顶点的索引
            unsigned int current = s * profileSize + i;
            unsigned int next = (s + 1) % steps * profileSize + i;

            // 为每个四边形创建两个三角形，确保顶点是逆时针顺序
            surface.VF.push_back(Tup3u(current, current + 1, next));
            surface.VF.push_back(Tup3u(next, current + 1, next + 1));
        }
    }
}




Surface makeSurfRev(const Curve &profile, unsigned steps)
{
    Surface surface; 
    // surface = quad();
    
    if (!checkFlat(profile))
    {
        cerr << "surfRev profile curve must be flat on xy plane." << endl;
        exit(0);
    }

    const float angleStep = 2.0f * M_PI / steps;

    // Reserve space for efficiency
    surface.VV.reserve(profile.size() * steps);
    surface.VN.reserve(profile.size() * steps);
    surface.VF.reserve((profile.size() - 1) * steps * 2); // two triangles per quad

    // Iterate over each step
    for (unsigned s = 0; s < steps; ++s) {
        // Compute rotation matrix for this step
        float angle = s * angleStep;
        Matrix4f rotationMatrix(
            cos(angle), 0, sin(angle), 0,
            0, 1, 0, 0,
            -sin(angle), 0, cos(angle), 0,
            0, 0, 0, 1
        );

        // Transform profile curve vertices and normals using the rotation matrix
        for (unsigned i = 0; i < profile.size(); ++i) {
            Vector4f pos(profile[i].V[0], profile[i].V[1], profile[i].V[2], 1);
            Vector4f normal(profile[i].N[0], profile[i].N[1], profile[i].N[2], 0);

            pos = rotationMatrix * pos;
            normal = rotationMatrix.inverse().transposed() * normal;  // Remove normalization temporarily
            normal = -normal.normalized();  // Negate and normalize the vector to reverse the direction

            // Add the vertex position and normal to the surface
            surface.VV.push_back(pos.xyz());
            surface.VN.push_back(normal.xyz());
        }
    }

    // 使用公共函数构建面片
    buildFaces(surface, steps, profile.size());
    return surface;
}



bool isClosedCurve(const Curve& curve) {
    // 判断曲线是否闭合：比较曲线首尾点的位置
    return (curve.front().V - curve.back().V).absSquared() < 1e-6;
}


void interpolateNormals(Curve& curve) {
    if (!isClosedCurve(curve)) return;

    // 获取曲线的起始和结束法向量
    Vector3f startNormal = curve.front().N;
    Vector3f endNormal = curve.back().N;

    if (startNormal[0] - endNormal[0] < 1e-5 && startNormal[1] - endNormal[1] < 1e-5 && startNormal[2] - endNormal[2] < 1e-5) return;

    // 计算起始和结束法向量之间的夹角 alpha
    float dot = Vector3f::dot(startNormal, endNormal);
    dot = std::max(-1.0f, std::min(1.0f, dot)); // 限制点积的范围为[-1, 1]以防止计算错误
    float alpha = std::acos(dot);

    // 计算每一段的旋转角度 theta
    float theta = alpha / curve.size();  // 使用 curve.size() 代替 surf_size

    for (size_t i = 0; i < curve.size(); ++i) {
        // 获取当前点的法向量和次法向量
        Vector3f N = curve[i].N.normalized();
        Vector3f B = curve[i].B.normalized();

        // 计算当前点的法线旋转角度
        float currentTheta = -theta * i; // i 从 0 到 curve.size()-1，平均分配角度

        // 使用简单的二维旋转公式更新法线
        Vector3f rotatedNormal = (std::cos(currentTheta) * N + std::sin(currentTheta) * B).normalized();

        // 标准化并更新当前点的法线
        curve[i].N = rotatedNormal;
    }
}


void interpolateBinormals(Curve& curve) {
    if (!isClosedCurve(curve)) return;

    // 获取曲线的起始和结束次法向量
    Vector3f startBinormal = curve.front().B;
    Vector3f endBinormal = curve.back().B;

    if (startBinormal[0] - endBinormal[0] < 1e-5 && startBinormal[1] - endBinormal[1] < 1e-5 && startBinormal[2] - endBinormal[2] < 1e-5) return;

    // 计算起始和结束次法向量之间的夹角 alpha
    float dot = Vector3f::dot(startBinormal, endBinormal);
    dot = std::max(-1.0f, std::min(1.0f, dot)); // 限制点积的范围为[-1, 1]以防止计算错误
    float alpha = std::acos(dot);

    // 计算每一段的旋转角度 theta
    float theta = alpha / curve.size();  // 使用 curve.size() 代替 surf_size

    for (size_t i = 0; i < curve.size(); ++i) {
        // 获取当前点的法向量和次法向量
        Vector3f N = curve[i].N.normalized();
        Vector3f B = curve[i].B.normalized();

        // 计算当前点的法线旋转角度
        float currentTheta = theta * i; // i 从 0 到 curve.size()-1，平均分配角度

        // 使用公式更新法线
        Vector3f rotatedBinormal = (std::cos(currentTheta) * B + std::sin(currentTheta) * N).normalized();

        // 标准化并更新当前点的法线
        curve[i].B = rotatedBinormal;
    }
}



Surface makeGenCyl(const Curve &profile, const Curve &sweep) {
    Surface surface;

    // 创建 sweep 副本以进行修改
    Curve sweepCopy = sweep;

    // 检查副本是否闭合，并对扫描曲线副本应用法线插值
    interpolateNormals(sweepCopy);
    interpolateBinormals(sweepCopy);
    sweepCopy.pop_back();

    if (!checkFlat(profile)) {
        cerr << "genCyl profile curve must be flat on xy plane." << endl;
        exit(0);
    }

    // 遍历sweep副本曲线，计算变换矩阵，并应用它们到profile曲线的每个点上
    Matrix4f M_inv_transpose;
    for (size_t i = 0; i < sweepCopy.size(); ++i) {
        const CurvePoint& sweepPt = sweepCopy[i];

        // 创建变换矩阵M，将轮廓曲线变换到正确的位置
        Matrix4f M = Matrix4f::identity();
        M.setCol(0, Vector4f(sweepPt.N, 0));
        M.setCol(1, Vector4f(sweepPt.B, 0));
        M.setCol(2, Vector4f(sweepPt.T, 0));
        M.setCol(3, Vector4f(sweepPt.V, 1));
        M_inv_transpose = M.inverse().transposed();

        for (size_t j = 0; j < profile.size(); ++j) {
            const CurvePoint& profilePt = profile[j];
            Vector4f P(profilePt.V, 1);
            Vector4f N(profilePt.N, 0);

            // 变换轮廓点和法向量
            Vector4f Pprime = M * P;
            Vector4f Nprime = M_inv_transpose * N;
            Nprime = -Nprime.normalized();

            // 将变换后的点Pprime和法向量Nprime添加到surface数据结构
            surface.VV.push_back(Pprime.xyz());
            surface.VN.push_back(Nprime.xyz());
        }
    }

    // 使用公共函数构建面片
    buildFaces(surface, sweepCopy.size(), profile.size());
    return surface;
}


void recordSurface(const Surface &surface, VertexRecorder* recorder) {
	const Vector3f WIRECOLOR(0.4f, 0.4f, 0.4f);
    for (int i=0; i<(int)surface.VF.size(); i++)
    {
		recorder->record(surface.VV[surface.VF[i][0]], surface.VN[surface.VF[i][0]], WIRECOLOR);
		recorder->record(surface.VV[surface.VF[i][1]], surface.VN[surface.VF[i][1]], WIRECOLOR);
		recorder->record(surface.VV[surface.VF[i][2]], surface.VN[surface.VF[i][2]], WIRECOLOR);
    }
}

void recordNormals(const Surface &surface, VertexRecorder* recorder, float len)
{
	const Vector3f NORMALCOLOR(0, 1, 1);
    for (int i=0; i<(int)surface.VV.size(); i++)
    {
		recorder->record_poscolor(surface.VV[i], NORMALCOLOR);
		recorder->record_poscolor(surface.VV[i] + surface.VN[i] * len, NORMALCOLOR);
    }
}

void outputObjFile(ostream &out, const Surface &surface)
{
    
    for (int i=0; i<(int)surface.VV.size(); i++)
        out << "v  "
            << surface.VV[i][0] << " "
            << surface.VV[i][1] << " "
            << surface.VV[i][2] << endl;

    for (int i=0; i<(int)surface.VN.size(); i++)
        out << "vn "
            << surface.VN[i][0] << " "
            << surface.VN[i][1] << " "
            << surface.VN[i][2] << endl;

    out << "vt  0 0 0" << endl;
    
    for (int i=0; i<(int)surface.VF.size(); i++)
    {
        out << "f  ";
        for (unsigned j=0; j<3; j++)
        {
            unsigned a = surface.VF[i][j]+1;
            out << a << "/" << "1" << "/" << a << " ";
        }
        out << endl;
    }
}


















/*
Surface makeSurfRev(const Curve &profile, unsigned steps)
{
    Surface surface; 
    // surface = quad();
    
    if (!checkFlat(profile))
    {
        cerr << "surfRev profile curve must be flat on xy plane." << endl;
        exit(0);
    }

    const float angleStep = 2.0f * M_PI / steps;

    // Reserve space for efficiency
    surface.VV.reserve(profile.size() * steps);
    surface.VN.reserve(profile.size() * steps);
    surface.VF.reserve((profile.size() - 1) * steps * 2); // two triangles per quad

    // Iterate over each step
    for (unsigned s = 0; s < steps; ++s) {
        // Compute rotation matrix for this step
        float angle = s * angleStep;
        Matrix4f rotationMatrix(
            cos(angle), 0, sin(angle), 0,
            0, 1, 0, 0,
            -sin(angle), 0, cos(angle), 0,
            0, 0, 0, 1
        );

        // Transform profile curve vertices and normals using the rotation matrix
        for (unsigned i = 0; i < profile.size(); ++i) {
            Vector4f pos(profile[i].V[0], profile[i].V[1], profile[i].V[2], 1);
            Vector4f normal(profile[i].N[0], profile[i].N[1], profile[i].N[2], 0);

            pos = rotationMatrix * pos;
            normal = rotationMatrix.inverse().transposed() * normal;  // Remove normalization temporarily
            normal = -normal.normalized();  // Negate and normalize the vector to reverse the direction

            // Add the vertex position and normal to the surface
            surface.VV.push_back(pos.xyz());
            surface.VN.push_back(normal.xyz());
        }
    }

    // 使用公共函数构建面片
    buildFaces(surface, steps, profile.size());
    return surface;
}



bool isClosedCurve(const Curve& curve) {
    // 判断曲线是否闭合：比较曲线首尾点的位置
    return (curve.front().V - curve.back().V).absSquared() < 1e-6;
}


void interpolateNormals(Curve& curve) {
    if (!isClosedCurve(curve)){
        cerr << "\t>>> not closed\n\t>>> do nothing" << endl;
        return;
    }

    // 获取曲线的起始和结束法向量
    Vector3f startNormal = curve.front().N;
    Vector3f endNormal = curve.back().N;

    cerr << "before rotation:" << endl;
    cerr << "startVertex: " << curve.front().V[0] << "\t" << curve.front().V[1] << "\t" << curve.front().V[2] << endl;
    cerr << "startTangent: " << curve.front().T[0] << "\t" << curve.front().T[1] << "\t" << curve.front().T[2] << endl;
    cerr << "startNormal: " << curve.front().N[0] << "\t" << curve.front().N[1] << "\t" << curve.front().N[2] << endl;
    cerr << "startBinormal: " << curve.front().B[0] << "\t" << curve.front().B[1] << "\t" << curve.front().B[2] << endl;
    cerr << "endVertex: " << curve.back().V[0] << "\t" << curve.back().V[1] << "\t" << curve.back().V[2] << endl;
    cerr << "endTangent: " << curve.back().T[0] << "\t" << curve.back().T[1] << "\t" << curve.back().T[2] << endl;
    cerr << "endNormal: " << curve.back().N[0] << "\t" << curve.back().N[1] << "\t" << curve.back().N[2] << endl;
    cerr << "endBinormal: " << curve.back().B[0] << "\t" << curve.back().B[1] << "\t" << curve.back().B[2] << endl;

    // 计算起始和结束法向量之间的夹角 alpha
    float dot = Vector3f::dot(startNormal, endNormal);
    cerr << "dot: " << dot << endl;
    dot = std::max(-1.0f, std::min(1.0f, dot)); // 限制点积的范围为[-1, 1]以防止计算错误
    float alpha = std::acos(dot);
    cerr << "alpha: " << alpha << endl;
    cerr << "curve.size: " << curve.size() << endl;

    // 计算每一段的旋转角度 theta
    float theta = alpha / curve.size();  // 使用 curve.size() 代替 surf_size

    for (size_t i = 0; i < curve.size(); ++i) {
        // 获取当前点的法向量和次法向量
        Vector3f N = curve[i].N.normalized();
        Vector3f B = curve[i].B.normalized();
        Vector3f T = curve[i].T.normalized();

        // 计算当前点的法线旋转角度
        float currentTheta = -theta * i; // i 从 0 到 curve.size()-1，平均分配角度
        //cerr << "currentTheta: " << currentTheta << endl;
        cerr << "original Tangent: " << T[0] << "\t" << T[1] << "\t" << T[2] << endl;
        cerr << "original Normal: " << N[0] << "\t" << N[1] << "\t" << N[2] << endl;
        cerr << "original BiNormal: " << B[0] << "\t" << B[1] << "\t" << B[2] << endl;
        // 使用简单的二维旋转公式更新法线
        Vector3f rotatedNormal = (std::cos(currentTheta) * N + std::sin(currentTheta) * B).normalized();
        //Vector3f rotatedBinormal = (std::cos(currentTheta) * B + std::sin(currentTheta) * N).normalized();
        //Vector3f rotatedBinormal = (Vector3f::cross(T,N)).normalized();
        cerr << "rotated Tangent: " << T[0] << "\t" << T[1] << "\t" << T[2] << endl;
        cerr << "rotated Normal: " << rotatedNormal[0] << "\t" << rotatedNormal[1] << "\t" << rotatedNormal[2] << endl;
        //cerr << "rotated BiNormal: " << rotatedBinormal[0] << "\t" << rotatedBinormal[1] << "\t" << rotatedBinormal[2] << endl;

        // 标准化并更新当前点的法线
        curve[i].N = rotatedNormal;
        //curve[i].B = rotatedBinormal;
    }
    cerr << "after rotation:" << endl;
    cerr << "startVertex: " << curve.front().V[0] << "\t" << curve.front().V[1] << "\t" << curve.front().V[2] << endl;
    cerr << "startTangent: " << curve.front().T[0] << "\t" << curve.front().T[1] << "\t" << curve.front().T[2] << endl;
    cerr << "startNormal: " << curve.front().N[0] << "\t" << curve.front().N[1] << "\t" << curve.front().N[2] << endl;
    cerr << "startBinormal: " << curve.front().B[0] << "\t" << curve.front().B[1] << "\t" << curve.front().B[2] << endl;
    cerr << "endVertex: " << curve.back().V[0] << "\t" << curve.back().V[1] << "\t" << curve.back().V[2] << endl;
    cerr << "endTangent: " << curve.back().T[0] << "\t" << curve.back().T[1] << "\t" << curve.back().T[2] << endl;
    cerr << "endNormal: " << curve.back().N[0] << "\t" << curve.back().N[1] << "\t" << curve.back().N[2] << endl;
    cerr << "endBinormal: " << curve.back().B[0] << "\t" << curve.back().B[1] << "\t" << curve.back().B[2] << endl;
}


void interpolateBinormals(Curve& curve) {
    if (!isClosedCurve(curve)){
        cerr << "\t>>> not closed\n\t>>> do nothing" << endl;
        return;
    }

    // 获取曲线的起始和结束次法向量
    Vector3f startBinormal = curve.front().B;
    Vector3f endBinormal = curve.back().B;

    // 计算起始和结束法向量之间的夹角 alpha
    float dot = Vector3f::dot(startBinormal, endBinormal);
    cerr << "dot: " << dot << endl;
    dot = std::max(-1.0f, std::min(1.0f, dot)); // 限制点积的范围为[-1, 1]以防止计算错误
    float alpha = std::acos(dot);
    cerr << "alpha: " << alpha << endl;
    cerr << "curve.size: " << curve.size() << endl;

    // 计算每一段的旋转角度 theta
    float theta = alpha / curve.size();  // 使用 curve.size() 代替 surf_size

    for (size_t i = 0; i < curve.size(); ++i) {
        // 获取当前点的法向量和次法向量
        Vector3f N = curve[i].N.normalized();
        Vector3f B = curve[i].B.normalized();
        Vector3f T = curve[i].T.normalized();

        // 计算当前点的法线旋转角度
        float currentTheta = theta * i; // i 从 0 到 curve.size()-1，平均分配角度
        //cerr << "currentTheta: " << currentTheta << endl;
        cerr << "original Tangent: " << T[0] << "\t" << T[1] << "\t" << T[2] << endl;
        cerr << "original Normal: " << N[0] << "\t" << N[1] << "\t" << N[2] << endl;
        cerr << "original BiNormal: " << B[0] << "\t" << B[1] << "\t" << B[2] << endl;
        // 使用简单的二维旋转公式更新法线
        Vector3f rotatedBinormal = (std::cos(currentTheta) * B + std::sin(currentTheta) * N).normalized();
        //Vector3f rotatedBinormal = (Vector3f::cross(T,N)).normalized();
        cerr << "rotated Tangent: " << T[0] << "\t" << T[1] << "\t" << T[2] << endl;
        //cerr << "rotated Normal: " << rotatedNormal[0] << "\t" << rotatedNormal[1] << "\t" << rotatedNormal[2] << endl;
        cerr << "rotated BiNormal: " << rotatedBinormal[0] << "\t" << rotatedBinormal[1] << "\t" << rotatedBinormal[2] << endl;

        // 标准化并更新当前点的法线
        curve[i].B = rotatedBinormal;
    }
    cerr << "after rotation:" << endl;
    cerr << "startVertex: " << curve.front().V[0] << "\t" << curve.front().V[1] << "\t" << curve.front().V[2] << endl;
    cerr << "startTangent: " << curve.front().T[0] << "\t" << curve.front().T[1] << "\t" << curve.front().T[2] << endl;
    cerr << "startNormal: " << curve.front().N[0] << "\t" << curve.front().N[1] << "\t" << curve.front().N[2] << endl;
    cerr << "startBinormal: " << curve.front().B[0] << "\t" << curve.front().B[1] << "\t" << curve.front().B[2] << endl;
    cerr << "endVertex: " << curve.back().V[0] << "\t" << curve.back().V[1] << "\t" << curve.back().V[2] << endl;
    cerr << "endTangent: " << curve.back().T[0] << "\t" << curve.back().T[1] << "\t" << curve.back().T[2] << endl;
    cerr << "endNormal: " << curve.back().N[0] << "\t" << curve.back().N[1] << "\t" << curve.back().N[2] << endl;
    cerr << "endBinormal: " << curve.back().B[0] << "\t" << curve.back().B[1] << "\t" << curve.back().B[2] << endl;
}

*/